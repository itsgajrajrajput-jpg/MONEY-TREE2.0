# Privacy Policy

This app does not collect or store any personal data. 
All transactions are handled securely through UPI. 
Users are responsible for ensuring compliance with their local laws.
